<?php
$EM_CONF[ $_EXTKEY ] = array (
  'title'             => 'Trumbowyg Editor',
  'description'       => 'Provides the Trumbowyg - Editor.',
  'category'          => 'editors',
  'version'           => '1.0.0',
  'state'             => 'stable',
  'uploadfolder'      => false,
  'clearcacheonload'  => true,
  'author'            => 'Callari Salvatore',
  'author_email'      => 'Callari@WaXCode.net',
  'author_company'    => NULL,
  'constraints'       => array (
    'depends'   => ['typo3' => '11.5.1-12.99.99'],
    'conflicts' => NULL,
    'suggests'  => array()));