﻿Known problems
--------------

- If you find a bug, please report it `here <https://github.com/CallariS/typowyg/pulls>`_.
