﻿Thanks to ...
^^^^^^^^^^^^^

`Alexandre Demode <https://github.com/Alex-D>`_ for creating the `Trumbowyg Editor <https://alex-d.github.io/Trumbowyg/>`_ and releasing it under the `MIT License <https://github.com/Alex-D/Trumbowyg/blob/develop/LICENSE>`_.