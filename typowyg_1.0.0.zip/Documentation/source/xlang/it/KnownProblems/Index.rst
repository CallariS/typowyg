﻿Bug noti
--------

- Si prega di segnalare eventuali bug riscontrati `qui <https://github.com/CallariS/typowyg/pulls>`_.