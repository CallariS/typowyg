﻿I miei ringraziamenti a ...
^^^^^^^^^^^^^^^^^^^^^^^^^^^

`Alexandre Demode <https://github.com/Alex-D>`_ per lo sviluppo del `Trumbowyg Editor <https://alex-d.github.io/Trumbowyg/>`_ e la pubblicazione sotto la `MIT Licence <https://github.com/Alex-D/Trumbowyg/blob/develop/LICENSE>`_.