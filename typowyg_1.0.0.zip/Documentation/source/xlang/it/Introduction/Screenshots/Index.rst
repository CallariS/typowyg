﻿.. raw:: html

  <style>
    @keyframes fadeIN_Images { 100% { scale : 1 ; opacity : 1 ;}}
    img { scale : 1.1 ; opacity : 0 ; animation : fadeIN_Images 1s ease-in forwards ;}</style>

Screenshots
^^^^^^^^^^^

La prima immagine mostra la tavolozza di configurazione nel backend. Le altre mostrano molte delle funzionalità offerte dall'editor `Trumbowyg <https://alex-d.github.io/Trumbowyg/>`_.

Date un'occhiata alla `Dimostrazione <https://waxcode.net/projects/sites/demo-typowyg>`_.

.. image:: ../../Images/Backshot.png

.. container:: table-row

   .. image:: ../../Images/Screenshot1.png
         
   .. image:: ../../Images/Screenshot2.png

.. container:: table-row

   .. image:: ../../Images/Screenshot3.png

   .. image:: ../../Images/Screenshot4.png


.. container:: table-row

   .. image:: ../../Images/Screenshot5.png

   .. image:: ../../Images/Screenshot6.png

.. container:: table-row

   .. image:: ../../Images/Screenshot7.png

   .. image:: ../../Images/Screenshot8.png

.. container:: table-row

   .. image:: ../../Images/Screenshot9.png

   .. image:: ../../Images/Screenshot10.png

.. container:: table-row

   .. image:: ../../Images/Screenshot11.png

   .. image:: ../../Images/Screenshot12.png

.. container:: table-row

   .. image:: ../../Images/Screenshot13.png

   .. image:: ../../Images/Screenshot14.png