.. raw:: html

  <style>
    @keyframes fadeIN_Table { 100% { scale : 1 ; opacity : 1 ;}}
    table.docutils                      { border : solid !important ; border-radius : .5em ; box-shadow : 0 0 .5em black ; opacity : 0 ; scale : 1.1 ; animation : fadeIN_Table 1s ease-in forwards ;}
    table.docutils p                    { font-family : monospace ;}
    table.docutils th                   { text-align  : center ;}
    table.docutils td                   { border : none ;}
    table.docutils tr:nth-child( even ) { background-color : grey ; color : white ;}
    table.docutils thead                { background-color : lightgrey ;}</style>

Note Di Rilascio
----------------

==========  ==============================================================================================================================
Versione    Cambiamenti
==========  ==============================================================================================================================
1.0.0       Caricamento iniziale sul TER.
==========  ==============================================================================================================================