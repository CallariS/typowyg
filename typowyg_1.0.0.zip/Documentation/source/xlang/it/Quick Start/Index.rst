﻿Avvio rapido
------------

Iniziate subito ad usarlo.

.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   Trumbowyg/Index
   Google Drive/Index