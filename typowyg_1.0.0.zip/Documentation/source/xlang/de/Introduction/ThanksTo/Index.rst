﻿Meinen Dank an ...
^^^^^^^^^^^^^^^^^^

`Alexandre Demode <https://github.com/Alex-D>`_ für die Entwicklung des `Trumbowyg Editors <https://alex-d.github.io/Trumbowyg/>`_ und der Veröffentlichung unter der `MIT License <https://github.com/Alex-D/Trumbowyg/blob/develop/LICENSE>`_.