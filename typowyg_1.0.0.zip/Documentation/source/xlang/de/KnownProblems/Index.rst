﻿Bekannte Bugs
-------------

- Gefundene Bugs bitte `hier <https://github.com/CallariS/typowyg/pulls>`_ melden.