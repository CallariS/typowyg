if( jQuery.trumbowyg.langs.en == undefined ) jQuery.trumbowyg.langs.en = {};

jQuery.trumbowyg.langs.en.link                  = 'LINK';
jQuery.trumbowyg.langs.en.unableToRetrieveFiles = "Retrieving the root-directory's filelisting failed due to following error: [%ERROR%]";
jQuery.trumbowyg.langs.en.loadingGAPI           = 'Loading Google API for Drive access. Try again later.';
jQuery.trumbowyg.langs.en.GAPI_NA               = 'Google API is not available. No access to your Google Drive can be granted.';
jQuery.trumbowyg.langs.en.webContentUnavailable = 'CANNOT EMBED THIS TYPE - LINKED INSTEAD';