if( jQuery.trumbowyg.langs.en == undefined ) jQuery.trumbowyg.langs.en = {};

jQuery.trumbowyg.langs.en.uploadError           = 'Failed uploading [%FILE%] due to following error: [%ERROR%]';
jQuery.trumbowyg.langs.en.unableToRetrieveFiles = 'File could not be renamed due to following error: [%ERROR%]';
jQuery.trumbowyg.langs.en.folderAdded           = 'New folder was added.';
jQuery.trumbowyg.langs.en.newFolderName         = 'New Folder';
jQuery.trumbowyg.langs.en.selectFileToEmbed     = 'Select the file to link / embed';
jQuery.trumbowyg.langs.en.unembedable           = 'Only files of type [%TYPE%] are embedable.';
jQuery.trumbowyg.langs.en.embedAccessWarning    = 'This will make the file to embed publicly available to anyone who has the generated link, if it is not already. Are you sure you want to embed the file?';
jQuery.trumbowyg.langs.en.selectFileToEmbed     = 'Select the file to embed';